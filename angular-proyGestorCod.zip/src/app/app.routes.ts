import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login';
import { Menu } from './components/menu/menu';
import { ListarSolicitudComponent } from './components/solicitud/listar-solicitud/listar-solicitud';
import { RegistrarSolicitudComponent } from './components/solicitud/registrar-solicitud/registrar-solicitud';
import { ListarUsuarioComponent } from './components/usuario/listar-usuario/listar-usuario';
import { RegistrarUsuarioComponent } from './components/usuario/registrar-usuario/registrar-usuario';
import { ListarPlataformaComponent } from './components/plataforma/listar-plataforma/listar-plataforma';
import { RegistrarPlataformaComponent } from './components/plataforma/registrar-plataforma/registrar-plataforma';

export const routes: Routes = [
    { path: 'login', component: LoginComponent },
    { 
        path: 'menu', component: Menu,
        children: [
            { path: 'listado', component: ListarSolicitudComponent },
            { path: 'registro', component: RegistrarSolicitudComponent },
            { path: 'usuarios', component: ListarUsuarioComponent },
            { path: 'usuarios/registro', component: RegistrarUsuarioComponent },
            { path: 'plataformas', component: ListarPlataformaComponent },
            { path: 'plataformas/registro', component: RegistrarPlataformaComponent }
        ]
    },
    { path: '', redirectTo: 'login', pathMatch: 'full' }
];