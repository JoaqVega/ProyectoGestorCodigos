import { Usuario } from "./usuario";

export interface Plataforma {
    idPlataforma: number;
    nombre: string;
    descripcion?: string;
    estado?: number;
}

export interface CorreoAutorizado {
    idCorreo: number;
    direccion: string;
}

export interface Solicitud {
    idSolicitud?: number;
    codigoVerificacion: string;
    fechaRegistro?: string;
    estadoSolicitud: string;
    
    // Objetos (Para Listar)
    plataforma?: Plataforma;
    usuario?: Usuario;
    correo?: CorreoAutorizado;

    // IDs (Para Registrar)
    id_plataforma?: number;
    id_correo?: number;
    id_usuario?: number;
}