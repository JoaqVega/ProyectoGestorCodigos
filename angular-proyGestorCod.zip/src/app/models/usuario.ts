export interface Usuario {
    idUsuario?: number;
    nombres?: string;
    apellidos?: string;
    correo: string;
    password?: string;
    idTipoRol?: number; // 1: Admin, 2: Operador
    estado?: number;    // 1: Activo, 0: Inactivo
}