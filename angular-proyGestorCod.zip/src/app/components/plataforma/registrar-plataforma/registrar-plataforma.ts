import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { PlataformaService } from '../../../services/plataforma-service';
import { Plataforma } from '../../../models/solicitud';

@Component({
  selector: 'app-registrar-plataforma',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './registrar-plataforma.html',
  styleUrl: './registrar-plataforma.css'
})
export class RegistrarPlataformaComponent {

  private service = inject(PlataformaService);
  private router = inject(Router);

  // Objeto simple
  obj: Plataforma = {
    idPlataforma: 0,
    nombre: '',
    descripcion: '' 
  };

  registrar() {
    // Agregamos estado por defecto si el backend lo pide
    const payload = { ...this.obj, estado: 1 };

    this.service.guardarPlataforma(payload).subscribe(() => {
      alert('Plataforma guardada');
      this.router.navigate(['/menu/plataformas']);
    });
  }
}