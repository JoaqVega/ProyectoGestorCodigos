import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrarPlataforma } from './registrar-plataforma';

describe('RegistrarPlataforma', () => {
  let component: RegistrarPlataforma;
  let fixture: ComponentFixture<RegistrarPlataforma>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RegistrarPlataforma]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegistrarPlataforma);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
