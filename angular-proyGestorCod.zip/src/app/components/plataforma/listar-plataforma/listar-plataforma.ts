import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router'; // Para el botón de "Nuevo"
import { PlataformaService } from '../../../services/plataforma-service';
import { Plataforma } from '../../../models/solicitud';

@Component({
  selector: 'app-listar-plataforma',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './listar-plataforma.html',
  styleUrl: './listar-plataforma.css'
})
export class ListarPlataformaComponent implements OnInit {

  private service = inject(PlataformaService);
  lista: Plataforma[] = [];

  ngOnInit(): void {
    this.cargar();
  }

  cargar() {
    this.service.listarPlataformas().subscribe(data => this.lista = data);
  }

  eliminar(id: number) {
    if(confirm('¿Eliminar plataforma? (Cuidado: Puede tener solicitudes asociadas)')) {
      this.service.eliminarPlataforma(id).subscribe({
        next: () => {
          alert('Eliminado correctamente');
          this.cargar();
        },
        error: () => alert('No se puede eliminar porque ya tiene solicitudes registradas.')
      });
    }
  }
}