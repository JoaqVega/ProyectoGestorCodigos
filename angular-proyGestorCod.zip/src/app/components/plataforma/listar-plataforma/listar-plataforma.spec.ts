import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListarPlataforma } from './listar-plataforma';

describe('ListarPlataforma', () => {
  let component: ListarPlataforma;
  let fixture: ComponentFixture<ListarPlataforma>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ListarPlataforma]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ListarPlataforma);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
