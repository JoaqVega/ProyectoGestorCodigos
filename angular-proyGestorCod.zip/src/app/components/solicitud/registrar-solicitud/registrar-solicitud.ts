import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { SolicitudService } from '../../../services/solicitud-service';
import { Solicitud, Plataforma, CorreoAutorizado } from '../../../models/solicitud';
import { AuthService } from '../../../services/auth-service';

@Component({
  selector: 'app-registrar-solicitud',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './registrar-solicitud.html',
  styleUrl: './registrar-solicitud.css'
})
export class RegistrarSolicitudComponent implements OnInit {
  service = inject(SolicitudService);
  auth = inject(AuthService);
  router = inject(Router);

  lstPlataformas: Plataforma[] = [];
  lstCorreos: CorreoAutorizado[] = [];

  obj: Solicitud = {
    codigoVerificacion: '', estadoSolicitud: 'PENDIENTE',
    id_plataforma: 0, id_correo: 0
  };

  ngOnInit() {
    this.service.listarPlataformas().subscribe(d => this.lstPlataformas = d);
    this.service.listarCorreos().subscribe(d => this.lstCorreos = d);
  }

  registrar() {
    const user = this.auth.obtenerDatosUsuario();
    const payload = {
        codigoVerificacion: this.obj.codigoVerificacion,
        estadoSolicitud: 'PENDIENTE',
        plataforma: { idPlataforma: this.obj.id_plataforma },
        correo: { idCorreo: this.obj.id_correo },
        usuario: { idUsuario: user ? user.idUsuario : 1 }
    };

    this.service.registrarSolicitud(payload).subscribe(() => {
        alert('Registrado');
        this.router.navigate(['/menu/listado']);
    });
  }
}