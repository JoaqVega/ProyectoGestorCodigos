import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrarSolicitud } from './registrar-solicitud';

describe('RegistrarSolicitud', () => {
  let component: RegistrarSolicitud;
  let fixture: ComponentFixture<RegistrarSolicitud>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RegistrarSolicitud]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegistrarSolicitud);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
