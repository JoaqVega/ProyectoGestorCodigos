import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common'; // IMPORTANTE
import { SolicitudService } from '../../../services/solicitud-service';
import { Solicitud } from '../../../models/solicitud';

@Component({
  selector: 'app-listar-solicitud',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './listar-solicitud.html',
  styleUrl: './listar-solicitud.css'
})
export class ListarSolicitudComponent implements OnInit {
  service = inject(SolicitudService);
  solicitudes: Solicitud[] = [];

  ngOnInit() {
    this.service.listarSolicitudes().subscribe(data => this.solicitudes = data);
  }

   eliminar(id: number | undefined) {
    if (!id) return; // Validación simple

    if (confirm('¿Estás seguro de eliminar esta solicitud?')) {
      this.service.eliminar(id).subscribe({
        next: () => {
          alert('Solicitud eliminada');
          // Recargamos la lista para ver los cambios
          this.service.listarSolicitudes().subscribe(data => this.solicitudes = data);
        },
        error: () => alert('Error al eliminar')
      });
    }
  }
}