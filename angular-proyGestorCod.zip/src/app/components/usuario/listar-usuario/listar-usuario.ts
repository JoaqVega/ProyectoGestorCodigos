import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common'; // Para *ngFor
import { RouterModule } from '@angular/router';
import { UsuarioService } from '../../../services/usuario-service';
import { Usuario } from '../../../models/usuario';

@Component({
  selector: 'app-listar-usuario',
  standalone: true,
  imports: [CommonModule, RouterModule], // Import para usar *ngFor y routerLink
  templateUrl: './listar-usuario.html',
  styleUrl: './listar-usuario.css'
})
export class ListarUsuarioComponent implements OnInit {

  private service = inject(UsuarioService);
  
  // Lista de usuarios
  usuarios: Usuario[] = [];

  ngOnInit(): void {
    this.cargarLista();
  }

  cargarLista() {
    this.service.listarUsuarios().subscribe(data => {
      this.usuarios = data;
    });
  }

  eliminar(id: number | undefined) {
    if(!id) return;
    
    if(confirm("¿Seguro de eliminar a este usuario?")) {
      this.service.eliminarUsuario(id).subscribe(() => {
        alert("Usuario eliminado");
        this.cargarLista(); // Refrescar tabla
      });
    }
  }
}