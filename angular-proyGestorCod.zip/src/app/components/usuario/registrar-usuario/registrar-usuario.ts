import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { UsuarioService } from '../../../services/usuario-service';
import { Usuario } from '../../../models/usuario';

@Component({
  selector: 'app-registrar-usuario',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule], // Imports obligatorios
  templateUrl: './registrar-usuario.html',
  styleUrl: './registrar-usuario.css'
})
export class RegistrarUsuarioComponent {

  private service = inject(UsuarioService);
  private router = inject(Router);

  // Lista manual de Roles para el Combo
  // En un sistema real esto podría venir de una tabla tb_roles
  lstRoles = [
    { id: 1, nombre: 'ADMINISTRADOR' },
    { id: 2, nombre: 'OPERADOR' }
  ];

  // Objeto para el formulario
  objUsuario: Usuario = {
    nombres: '',
    apellidos: '',
    correo: '',
    password: '',
    idTipoRol: 2, // Por defecto Operador
    estado: 1     // Por defecto Activo
  };

  registrar() {
    this.service.registrarUsuario(this.objUsuario).subscribe({
      next: (resp) => {
        alert("¡Usuario registrado con éxito!");
        this.router.navigate(['/menu/usuarios']);
      },
      error: (err) => {
        console.error(err);
        alert("Error al registrar usuario (Revisa que el correo no se repita)");
      }
    });
  }
}