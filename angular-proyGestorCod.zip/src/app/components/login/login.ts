import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth-service';
import { Usuario } from '../../models/usuario';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class LoginComponent {
  auth = inject(AuthService);
  router = inject(Router);
  usuario: Usuario = { correo: '', password: '' };

  login() {
    this.auth.login(this.usuario).subscribe({
      next: (resp) => {
        // Guardamos token (esto solo funciona en navegador, OK por el click)
        localStorage.setItem('token', resp.token);
        localStorage.setItem('usuario_data', JSON.stringify(resp));
        this.router.navigate(['/menu/listado']);
      },
      error: () => alert('Credenciales incorrectas')
    });
  }
}