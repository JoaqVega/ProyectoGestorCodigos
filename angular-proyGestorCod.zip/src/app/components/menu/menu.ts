import { Component, inject } from '@angular/core';
import { Router, RouterModule, RouterOutlet } from '@angular/router';
import { AuthService } from '../../services/auth-service';  
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [RouterOutlet, RouterModule, CommonModule],
  templateUrl: './menu.html',
  styleUrl: './menu.css',
})
export class Menu {
  private auth = inject(AuthService);
  private router = inject(Router);

  // Variable para saber si es admin
  isAdmin: boolean = false;

  ngOnInit(): void {
    // Obtenemos los datos del usuario guardados al loguearse
    const user = this.auth.obtenerDatosUsuario();
    
    if (user) {
      // En tu BD, 1 es Admin y 2 es Operador
      this.isAdmin = user.rol === 'ADMIN'; 
    }
  }

  logout() {
    this.auth.logout();
    this.router.navigate(['/login']);
  }

}
