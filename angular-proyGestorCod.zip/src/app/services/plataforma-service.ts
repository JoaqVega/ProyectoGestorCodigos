import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Plataforma } from '../models/solicitud'; // Reutilizamos la interfaz que ya existe

@Injectable({ providedIn: 'root' })
export class PlataformaService {
  
  private http = inject(HttpClient);
  // Ruta del Backend para plataformas
  private urlBase = 'http://localhost:8080/api/plataformas';

  // 1. Listar
  listarPlataformas(): Observable<Plataforma[]> {
    return this.http.get<Plataforma[]>(this.urlBase);
  }

  // 2. Registrar (POST)
  // Según PlataformaController: @PostMapping("/guardar")
  guardarPlataforma(obj: Plataforma): Observable<any> {
    return this.http.post(this.urlBase + '/guardar', obj);
  }

  // 3. Eliminar (DELETE)
  eliminarPlataforma(id: number): Observable<any> {
    return this.http.delete(`${this.urlBase}/${id}`);
  }
}