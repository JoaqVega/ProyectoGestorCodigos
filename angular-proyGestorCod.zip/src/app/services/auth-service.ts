import { HttpClient } from '@angular/common/http';
import { Injectable, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Observable } from 'rxjs';
import { Usuario } from '../models/usuario';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private platformId = inject(PLATFORM_ID);
  private url = 'http://localhost:8080/api/auth'; 

  login(usuario: Usuario): Observable<any> {
    return this.http.post(`${this.url}/login`, usuario);
  }

  logout() {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('token');
      localStorage.removeItem('usuario_data');
    }
  }

  obtenerDatosUsuario(): any {
    if (isPlatformBrowser(this.platformId)) {
       const data = localStorage.getItem('usuario_data');
       return data ? JSON.parse(data) : null;
    }
    return null;
  }
}