import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Observable } from 'rxjs';
import { Usuario } from '../models/usuario';

@Injectable({ providedIn: 'root' })
export class UsuarioService {
  
  private http = inject(HttpClient);
  private platformId = inject(PLATFORM_ID);
  
  // Ruta del Backend para usuarios
  private urlBase = 'http://localhost:8080/api/usuarios';

  // Helper para obtener el token (Igual que en SolicitudService)
  // Nota: Si ya tienes el Interceptor funcionando, este método sobra, 
  // pero lo dejo por si acaso prefieres enviarlo manual en algún momento.
  private getHeaders(): HttpHeaders {
    let headers = new HttpHeaders();
    if (isPlatformBrowser(this.platformId)) {
      const token = localStorage.getItem('token');
      if (token) {
        headers = headers.set('Authorization', `Bearer ${token}`);
      }
    }
    return headers;
  }

  // 1. Listar Usuarios
  listarUsuarios(): Observable<Usuario[]> {
    return this.http.get<Usuario[]>(this.urlBase);
  }

  // 2. Registrar Usuario (POST)
  // El backend usa "/guardar" según tu UsuarioController
  registrarUsuario(obj: Usuario): Observable<any> {
    return this.http.post(this.urlBase + '/guardar', obj);
  }

  // 3. Eliminar Usuario (DELETE)
  eliminarUsuario(id: number): Observable<any> {
    return this.http.delete(`${this.urlBase}/${id}`);
  }
  
  // 4. Obtener por ID (Opcional, para editar)
  obtenerPorId(id: number): Observable<Usuario> {
    return this.http.get<Usuario>(`${this.urlBase}/${id}`);
  }
}