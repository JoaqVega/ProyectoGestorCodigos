import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Solicitud, Plataforma, CorreoAutorizado } from '../models/solicitud';

@Injectable({ providedIn: 'root' })
export class SolicitudService {
  
  private http = inject(HttpClient); 
  private urlBase = 'http://localhost:8080/api/solicitudes';

  // Listar
  listarSolicitudes(): Observable<Solicitud[]> {
    return this.http.get<Solicitud[]>(this.urlBase);
  }

  // Registrar
  registrarSolicitud(obj: any): Observable<any> {
    return this.http.post(this.urlBase + '/registrar', obj);
  }

  // Combos
  listarPlataformas(): Observable<Plataforma[]> {
    return this.http.get<Plataforma[]>('http://localhost:8080/api/plataformas');
  }

  listarCorreos(): Observable<CorreoAutorizado[]> {
    return this.http.get<CorreoAutorizado[]>(this.urlBase + '/aux/correos');
  }

  // Eliminar
  eliminar(id: number): Observable<any> {
    return this.http.delete(`${this.urlBase}/${id}`);
  }
}