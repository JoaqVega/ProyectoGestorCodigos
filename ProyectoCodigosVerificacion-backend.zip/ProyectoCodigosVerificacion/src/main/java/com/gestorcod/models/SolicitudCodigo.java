package com.gestorcod.models;

import java.time.LocalDateTime;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "tb_solicitudes")
@Data
public class SolicitudCodigo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_solicitud")
    private Integer idSolicitud;

    @Column(name = "codigo_verificacion", nullable = false, length = 20)
    private String codigoVerificacion;

    @Column(name = "fecha_registro")
    private LocalDateTime fechaRegistro;

    @Column(name = "fecha_vencimiento")
    private LocalDateTime fechaVencimiento;

    @Column(name = "estado_solicitud", length = 20)
    private String estadoSolicitud; // PENDIENTE, USADO, VENCIDO

    // --- RELACIONES (Foreign Keys) ---

    // Usuario que registró el código
    @ManyToOne
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario;

    // Plataforma a la que pertenece el código
    @ManyToOne
    @JoinColumn(name = "id_plataforma", nullable = false)
    private Plataforma plataforma;

    // Correo al que llegó el código
    @ManyToOne
    @JoinColumn(name = "id_correo", nullable = false)
    private CorreoAutorizado correo;

    // Asignar fecha automáticamente antes de guardar
    @PrePersist
    public void asignarFechaRegistro() {
        if (this.fechaRegistro == null) {
            this.fechaRegistro = LocalDateTime.now();
        }
        if (this.estadoSolicitud == null) {
            this.estadoSolicitud = "PENDIENTE";
        }
    }
}