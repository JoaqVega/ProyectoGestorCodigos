package com.gestorcod.models;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "tb_plataformas")
@Data
public class Plataforma {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_plataforma")
    private Integer idPlataforma;

    @Column(nullable = false, length = 50)
    private String nombre;

    @Column(length = 200)
    private String descripcion;

    private Integer estado;
}