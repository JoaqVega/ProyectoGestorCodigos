package com.gestorcod.models;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "tb_usuarios")
@Data
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_usuario")
    private Integer idUsuario;

    @Column(nullable = false, length = 100)
    private String nombres;

    @Column(nullable = false, length = 100)
    private String apellidos;

    @Column(nullable = false, unique = true, length = 100)
    private String correo; // Se usará como 'username' en el Login

    @Column(nullable = false)
    private String password; // Se guardará encriptada (BCrypt)

    @Column(name = "id_tipo_rol")
    private Integer idTipoRol; // 1: Admin, 2: Operador

    private Integer estado; // 1: Activo, 0: Inactivo
}