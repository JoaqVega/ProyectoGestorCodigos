package com.gestorcod.models;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "tb_correos")
@Data
public class CorreoAutorizado {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_correo")
    private Integer idCorreo;

    @Column(nullable = false, unique = true, length = 100)
    private String direccion; // Ej: finanzas@ciberfarma.com

    @Column(length = 100)
    private String responsable; // Ej: Juan Pérez

    private Integer estado;

    // Relación Muchos a Uno con Dominio
    @ManyToOne
    @JoinColumn(name = "id_dominio", nullable = false)
    private DominioPermitido dominio;
}