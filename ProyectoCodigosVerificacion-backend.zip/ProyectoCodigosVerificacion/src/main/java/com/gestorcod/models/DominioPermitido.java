package com.gestorcod.models;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "tb_dominios")
@Data
public class DominioPermitido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_dominio")
    private Integer idDominio;

    @Column(name = "nombre_dominio", nullable = false, length = 100)
    private String nombreDominio; // Ej: ciberfarma.com

    private Integer estado;
}