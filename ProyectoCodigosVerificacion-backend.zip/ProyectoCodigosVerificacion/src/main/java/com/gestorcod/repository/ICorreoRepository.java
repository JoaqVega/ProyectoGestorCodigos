package com.gestorcod.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gestorcod.models.CorreoAutorizado;

@Repository
public interface ICorreoRepository extends JpaRepository<CorreoAutorizado, Integer> {

}