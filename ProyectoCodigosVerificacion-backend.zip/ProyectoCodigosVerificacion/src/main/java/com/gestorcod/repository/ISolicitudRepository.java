package com.gestorcod.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gestorcod.models.SolicitudCodigo;

@Repository
public interface ISolicitudRepository extends JpaRepository<SolicitudCodigo, Integer> {
    
    // Aquí podríamos agregar filtros a futuro, por ejemplo:
    // List<SolicitudCodigo> findByEstadoSolicitud(String estado);
}