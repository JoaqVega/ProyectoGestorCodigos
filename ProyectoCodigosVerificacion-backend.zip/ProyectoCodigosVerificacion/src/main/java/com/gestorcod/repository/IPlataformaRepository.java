package com.gestorcod.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gestorcod.models.Plataforma;

@Repository
public interface IPlataformaRepository extends JpaRepository<Plataforma, Integer> {

}