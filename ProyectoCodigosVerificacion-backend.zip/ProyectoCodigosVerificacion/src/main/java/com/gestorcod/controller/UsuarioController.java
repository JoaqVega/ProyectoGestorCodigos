package com.gestorcod.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.gestorcod.models.Usuario;
import com.gestorcod.service.UsuarioService;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = "http://localhost:4200")
public class UsuarioController {

    @Autowired
    private UsuarioService service;

    @GetMapping
    public ResponseEntity<List<Usuario>> listar() {
        return ResponseEntity.ok(service.listarTodos());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> obtenerPorId(@PathVariable Integer id) {
        Usuario obj = service.obtenerPorId(id);
        if(obj == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(obj);
    }

    // Ojo: Al usar este endpoint, el Service se encarga de encriptar la clave
    @PostMapping("/guardar")
    public ResponseEntity<Usuario> guardar(@RequestBody Usuario obj) {
        return ResponseEntity.ok(service.guardar(obj));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return ResponseEntity.ok().build();
    }
}