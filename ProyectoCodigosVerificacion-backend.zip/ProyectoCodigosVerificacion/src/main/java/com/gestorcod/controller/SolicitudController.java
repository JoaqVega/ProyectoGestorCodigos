package com.gestorcod.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.gestorcod.models.SolicitudCodigo;
import com.gestorcod.models.Plataforma;
import com.gestorcod.models.CorreoAutorizado;
import com.gestorcod.service.SolicitudService;
import com.gestorcod.service.PlataformaService; // Para llenar combos

@RestController
@RequestMapping("/api/solicitudes")
@CrossOrigin(origins = "http://localhost:4200")
public class SolicitudController {

    @Autowired
    private SolicitudService service;

    // --- CRUD DE SOLICITUDES ---

    @GetMapping
    public ResponseEntity<List<SolicitudCodigo>> listar() {
        return ResponseEntity.ok(service.listarTodas());
    }

    @PostMapping("/registrar")
    public ResponseEntity<SolicitudCodigo> registrar(@RequestBody SolicitudCodigo obj) {
        return ResponseEntity.ok(service.guardar(obj));
    }
    
    // PUT para actualizar (ej: marcar como USADO)
    @PutMapping("/actualizar")
    public ResponseEntity<SolicitudCodigo> actualizar(@RequestBody SolicitudCodigo obj) {
        return ResponseEntity.ok(service.guardar(obj));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return ResponseEntity.ok().build();
    }
    
    // --- ENDPOINTS AUXILIARES PARA COMBOS (Dropdowns) ---
    // A veces se ponen aquí por comodidad del frontend, o en sus propios controladores
    
    @GetMapping("/aux/correos")
    public ResponseEntity<List<CorreoAutorizado>> listarCorreosAux() {
        return ResponseEntity.ok(service.listarCorreos());
    }
}