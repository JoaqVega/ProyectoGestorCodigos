package com.gestorcod.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gestorcod.models.Usuario;
import com.gestorcod.security.JwtUtil;
import com.gestorcod.service.UsuarioService;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:4200") // Para Angular
public class AuthController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Usuario loginRequest) {
        try {
            // 1. Buscamos el usuario por correo
            Usuario usuarioEncontrado = usuarioService.buscarPorCorreo(loginRequest.getCorreo());

            // 2. Validamos si existe
            if (usuarioEncontrado == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Usuario no encontrado");
            }

            // 3. Validamos la contraseña (encriptada vs texto plano)
            if (!passwordEncoder.matches(loginRequest.getPassword(), usuarioEncontrado.getPassword())) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Contraseña incorrecta");
            }

            // 4. Si todo está OK, generamos el Token
            String rol = (usuarioEncontrado.getIdTipoRol() == 1) ? "ADMIN" : "OPERADOR";
            String token = jwtUtil.generarToken(usuarioEncontrado.getCorreo(), rol);

            // 5. Devolvemos el Token y datos del usuario al Frontend
            return ResponseEntity.ok(Map.of(
                "token", token,
                "usuario", usuarioEncontrado.getNombres() + " " + usuarioEncontrado.getApellidos(),
                "rol", rol,
                "idUsuario", usuarioEncontrado.getIdUsuario() // Útil para registrar solicitudes
            ));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error en el servidor: " + e.getMessage());
        }
    }
    
    // Opcional: Endpoint para registrar un usuario inicial si la BD está vacía
    // (Recuerda que ya te di un script SQL con usuarios, pero esto es útil)
    @PostMapping("/registrar")
    public ResponseEntity<Usuario> registrar(@RequestBody Usuario u) {
        Usuario nuevo = usuarioService.guardar(u);
        return ResponseEntity.ok(nuevo);
    }
}