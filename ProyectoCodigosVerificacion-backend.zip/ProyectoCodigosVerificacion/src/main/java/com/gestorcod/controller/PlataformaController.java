package com.gestorcod.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.gestorcod.models.Plataforma;
import com.gestorcod.service.PlataformaService;

@RestController
@RequestMapping("/api/plataformas")
@CrossOrigin(origins = "http://localhost:4200")
public class PlataformaController {

    @Autowired
    private PlataformaService service;

    @GetMapping
    public ResponseEntity<List<Plataforma>> listar() {
        return ResponseEntity.ok(service.listarTodas());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Plataforma> obtenerPorId(@PathVariable Integer id) {
        Plataforma obj = service.obtenerPorId(id);
        if(obj == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(obj);
    }

    @PostMapping("/guardar")
    public ResponseEntity<Plataforma> guardar(@RequestBody Plataforma obj) {
        return ResponseEntity.ok(service.guardar(obj));
    }
    
    @PutMapping("/actualizar")
    public ResponseEntity<Plataforma> actualizar(@RequestBody Plataforma obj) {
        return ResponseEntity.ok(service.guardar(obj));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return ResponseEntity.ok().build();
    }
}