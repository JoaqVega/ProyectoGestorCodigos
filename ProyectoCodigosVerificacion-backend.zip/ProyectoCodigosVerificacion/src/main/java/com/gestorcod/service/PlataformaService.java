package com.gestorcod.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gestorcod.models.Plataforma;
import com.gestorcod.repository.IPlataformaRepository;

@Service
public class PlataformaService {

    @Autowired
    private IPlataformaRepository repo;

    // C (Create) y U (Update)
    public Plataforma guardar(Plataforma p) {
        return repo.save(p);
    }

    // R (Read)
    public List<Plataforma> listarTodas() {
        return repo.findAll();
    }
    
    public Plataforma obtenerPorId(Integer id) {
        return repo.findById(id).orElse(null);
    }

    // D (Delete)
    public void eliminar(Integer id) {
        repo.deleteById(id);
    }
}