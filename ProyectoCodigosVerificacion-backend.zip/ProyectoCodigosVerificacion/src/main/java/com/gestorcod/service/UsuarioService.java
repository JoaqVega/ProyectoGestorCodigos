package com.gestorcod.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder; // Ojo: Necesitas configurar SecurityConfig luego
import org.springframework.stereotype.Service;

import com.gestorcod.models.Usuario;
import com.gestorcod.repository.IUsuarioRepository;

@Service
public class UsuarioService {

    @Autowired
    private IUsuarioRepository repo;
    
    @Autowired
    private PasswordEncoder passwordEncoder; // Esto se inyectará desde tu configuración de seguridad

    // --- LÓGICA PARA CRUD ---
    
    public List<Usuario> listarTodos() {
        return repo.findAll();
    }
    
    public Usuario obtenerPorId(Integer id) {
        return repo.findById(id).orElse(null);
    }

    // Registrar o Actualizar Usuario (Encriptando clave)
    public Usuario guardar(Usuario u) {
        // Solo encriptamos si el usuario es nuevo o si está enviando una nueva contraseña
        // Nota: Para un update real a veces se valida si la clave viene vacía para no sobreescribirla, 
        // pero para este ejemplo simple, asumiremos que siempre se encripta al guardar.
        u.setPassword(passwordEncoder.encode(u.getPassword()));
        return repo.save(u);
    }

    public void eliminar(Integer id) {
        repo.deleteById(id);
    }

    // --- LÓGICA PARA LOGIN ---
    
    public Usuario buscarPorCorreo(String correo) {
        return repo.findByCorreo(correo).orElse(null);
    }
}