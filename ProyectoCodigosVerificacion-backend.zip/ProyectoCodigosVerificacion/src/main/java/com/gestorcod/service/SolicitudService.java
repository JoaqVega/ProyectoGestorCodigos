package com.gestorcod.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gestorcod.models.SolicitudCodigo;
import com.gestorcod.models.CorreoAutorizado;
import com.gestorcod.repository.ISolicitudRepository;
import com.gestorcod.repository.ICorreoRepository;

@Service
public class SolicitudService {

    @Autowired
    private ISolicitudRepository repoSolicitud;
    
    @Autowired
    private ICorreoRepository repoCorreo;

    // R (Read)
    public List<SolicitudCodigo> listarTodas() {
        return repoSolicitud.findAll();
    }
    
    public SolicitudCodigo obtenerPorId(Integer id) {
        return repoSolicitud.findById(id).orElse(null);
    }

    // C (Create) y U (Update)
    public SolicitudCodigo guardar(SolicitudCodigo s) {
        // Aquí podrías agregar validaciones extra antes de guardar
        return repoSolicitud.save(s);
    }

    // D (Delete)
    public void eliminar(Integer id) {
        repoSolicitud.deleteById(id);
    }
    
    // Método auxiliar para llenar el Combo de Correos en el Frontend
    public List<CorreoAutorizado> listarCorreos() {
        return repoCorreo.findAll();
    }
}