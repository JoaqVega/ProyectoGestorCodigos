package com.gestorcod.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.gestorcod.models.Usuario;
import com.gestorcod.repository.IUsuarioRepository;

import java.util.Collections;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private IUsuarioRepository repoUsuario;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Buscamos el usuario por correo (que es nuestro username)
        Usuario usuario = repoUsuario.findByCorreo(username)
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado: " + username));

        // Convertimos el rol numérico a un String que entienda Spring Security
        // 1 = ADMIN, 2 = OPERADOR (o cualquier otro)
        String rol = (usuario.getIdTipoRol() == 1) ? "ROLE_ADMIN" : "ROLE_OPERADOR";
        GrantedAuthority authority = new SimpleGrantedAuthority(rol);

        // Retornamos el objeto User de Spring Security
        return new User(
                usuario.getCorreo(),
                usuario.getPassword(),
                Collections.singletonList(authority) // Lista de roles (solo 1 en este caso)
        );
    }
}