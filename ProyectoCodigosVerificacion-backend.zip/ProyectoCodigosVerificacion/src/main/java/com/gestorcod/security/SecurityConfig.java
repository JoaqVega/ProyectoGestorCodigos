package com.gestorcod.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private JwtFilter jwtFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) // Deshabilitamos CSRF
            .cors(org.springframework.security.config.Customizer.withDefaults()) 
            .formLogin(login -> login.disable()) // Deshabilitamos formulario de login por defecto
            .httpBasic(basic -> basic.disable()) // Deshabilitamos auth básica (usaremos Token)
            
            // CONFIGURACIÓN DE RUTAS (Aquí es donde cambia la lógica de negocio)
            .authorizeHttpRequests(auth -> auth
                
                // 1. RUTAS PÚBLICAS (No piden token)
                // El login debe ser público sí o sí
                .requestMatchers(HttpMethod.POST, "/api/auth/login").permitAll() 
                // Si quieres que registrar usuarios sea público (opcional):
                .requestMatchers(HttpMethod.POST, "/api/auth/registrar").permitAll() 
                //.requestMatchers(HttpMethod.GET, "/api/auth/registrar").permitAll() 
                
                // 2. RUTAS PROTEGIDAS (Piden Token)
                // Todo lo que sea gestión de solicitudes, plataformas y correos
                .requestMatchers("/api/solicitudes/**").authenticated()
                .requestMatchers("/api/plataformas/**").authenticated()
                .requestMatchers("/api/correos/**").authenticated()
                .requestMatchers("/api/usuarios/**").authenticated()

                // Cualquier otra ruta no especificada requiere login
                .anyRequest().authenticated()
            );

        // Agregamos el filtro de JWT antes del de autenticación
        http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    // Bean para encriptar contraseñas (OBLIGATORIO para que funcione UsuarioService)
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}